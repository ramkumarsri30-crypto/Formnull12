# FormNull — Phase 1

Production-grade SaaS foundation for building forms manually (AI builder lands in a later phase). Built on **Supabase only** — Auth, PostgreSQL, Storage, RLS, and Edge Functions. No Firebase, no hybrid architecture.

## Stack

- **Frontend**: Next.js 16 (App Router) · TypeScript 5 · Tailwind CSS 4 · shadcn/ui (New York)
- **Backend**: Supabase (Auth · PostgreSQL · Storage · RLS)
- **Design language**: Memphis / Playful Geometric — applied globally, not just the landing page
- **Auth**: PKCE flow · HTTP-only cookies · `@supabase/ssr`
- **State**: React Context for auth · SWR-style hooks for data

## Phase 1 — What's built

### Architecture
- ✅ Next.js 16 + TypeScript strict mode + Tailwind 4 + shadcn/ui
- ✅ Supabase-only backend (Auth, PostgreSQL, Storage, RLS)
- ✅ Zero Firebase presence (verified — no imports, no config, no hybrid)
- ✅ Cookie-based auth via `@supabase/ssr` with PKCE flow
- ✅ Route protection via `src/proxy.ts` (Next.js 16 middleware convention)
- ✅ Service role key never exposed to the browser (server-only utilities)

### Database (4 immutable migrations)
- `001_profiles_workspaces_members.sql` — profiles, workspaces, workspace_members, workspace_invites, sign-up trigger, role helper functions
- `002_forms_versions_fields.sql` — forms, form_versions (immutable), form_fields (normalized, not JSON)
- `003_submissions_values.sql` — submissions, submission_values (separate tables, never stored in form row), keyset pagination indexes, BRIN index for time-range scans
- `004_assets_and_storage.sql` — assets table, 5 storage buckets, storage RLS policies

All migrations use `IF NOT EXISTS` / `DO $$` blocks for idempotency. **Existing migrations are never modified** — corrective changes go in a new migration.

### Security
- RLS enabled on every user-owned table
- Storage policies enforce path-based ownership (`avatars/{user_id}/...`, `workspaces/{workspace_id}/...`, etc.)
- Helper functions (`fn_user_is_workspace_member`, `fn_user_can_edit_workspace`, etc.) used by RLS policies to avoid repeating subqueries
- `form_versions` is append-only — no UPDATE or DELETE even for admins (immutability guarantee)
- Service role key restricted to server-side utilities (`supabaseAdmin()`)

### Design system (Memphis / Playful Geometric)
- Design tokens in `src/app/globals.css` — colors, typography, spacing, radius, shadows, motion
- Memphis accent palette: coral, mint, sun, violet, sky, pink, lemon, ink
- Reusable decoration components: `GeometricCircle`, `GeometricSquare`, `GeometricTriangle`, `GeometricSemiCircle`, `GeometricZigZag`, `DotPattern`, `GridPattern`, `StripePattern`, `MemphisDecoration`
- Memphis Button variants: `memphis`, `memphis-coral`, `memphis-mint`, `memphis-outline` (signature offset shadow)
- State components: `EmptyState`, `ErrorState`, `LoadingState` — all decorated
- Consistent visual identity across landing, auth, dashboard, forms, settings, empty/loading/error states

### Pages
- `/` — Landing page (hero, features, stats, architecture, CTA, footer)
- `/signin`, `/signup`, `/forgot-password`, `/reset-password` — Auth pages with validation + loading + error states
- `/auth/callback` — Email verification + OAuth callback handler
- `/dashboard` — Overview with welcome banner, stat cards, recent forms
- `/dashboard/forms` — Forms list with empty state
- `/dashboard/forms/new` — New form creation (name, description, fields)
- `/dashboard/forms/[id]` — Form detail (edit, view fields, delete)
- `/dashboard/settings` — Profile + workspace settings

### Responsive
Tested at every required viewport width with **zero horizontal scrolling**:
320, 360, 375, 390, 414, 430, 600, 768, 820, 834, 912, 1024, 1280, 1366, 1440, 1536, 1920, 2560.

Layout changes are intentional, not just scaling:
- Desktop: persistent left sidebar (260px)
- Tablet/mobile: hidden sidebar, hamburger opens drawer
- Multi-column grids collapse to single-column
- Decorative shapes resize/reposition or disappear at small widths

### Accessibility
- Semantic HTML (`main`, `header`, `nav`, `section`, `article`)
- ARIA labels on icon-only buttons
- `aria-invalid` + `aria-describedby` on form fields with errors
- `role="alert"` on error states, `role="status"` on loading states
- Visible focus rings (`focus-visible:ring-2`)
- `prefers-reduced-motion` respected (animations disabled)
- Color is never the only indicator of state (text labels accompany status dots)

## Setup

### 1. Environment

`.env.local` is already configured:

```
NEXT_PUBLIC_SUPABASE_URL=https://sqtolkfjnskyxnltuyci.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=sb_publishable_...
NEXT_PUBLIC_SITE_URL=http://localhost:3000
SUPABASE_SERVICE_ROLE_KEY=sb_secret_...   # SERVER-ONLY — never import in client code
```

### 2. Apply database migrations

The migration files in `supabase/migrations/` are the canonical source of truth. Apply them in order via the Supabase Dashboard:

1. Open https://supabase.com/dashboard/project/sqtolkfjnskyxnltuyci/sql/new
2. For each file below, copy its contents into the SQL Editor and click **Run**:
   - `supabase/migrations/001_profiles_workspaces_members.sql`
   - `supabase/migrations/002_forms_versions_fields.sql`
   - `supabase/migrations/003_submissions_values.sql`
   - `supabase/migrations/004_assets_and_storage.sql`

Alternatively, if you have the Supabase CLI configured with database access:

```bash
supabase db push
```

### 3. Verify migrations

```bash
bun run scripts/verify-migrations.ts
```

This checks that all tables, RLS policies, storage buckets, helper functions, and the sign-up trigger are installed.

### 4. (Optional) Auto-apply migrations

If you have a database password, set `DATABASE_URL` in `.env.local`:

```
DATABASE_URL=postgresql://postgres.sqtolkfjnskyxnltuyci:{password}@aws-0-{region}.pooler.supabase.com:6543/postgres
```

Then run:

```bash
bun run scripts/apply-migrations.ts
```

This will apply all migrations directly via Postgres connection.

## Development

```bash
bun run dev      # Start dev server (port 3000)
bun run lint     # ESLint
npx tsc --noEmit # TypeScript check
bun run build    # Production build
```

## Project structure

```
src/
  app/
    layout.tsx              # Root layout — fonts, providers, metadata
    page.tsx                # Landing page
    globals.css             # Memphis design tokens
    signin/                 # Sign-in page
    signup/                 # Sign-up page
    forgot-password/        # Forgot-password page
    reset-password/         # Reset-password page
    auth/callback/route.ts  # Email verification callback
    dashboard/              # Protected dashboard
      page.tsx              # Overview
      forms/                # Forms list + new + detail
      settings/             # Profile + workspace settings
  proxy.ts                  # Next.js 16 middleware (route protection + session refresh)
  components/
    ui/                     # shadcn/ui base components
    memphis/                # Memphis decoration components
    formnull/               # FormNull-specific components (Logo, states)
  features/
    auth/                   # AuthProvider, AuthShell
    dashboard/              # DashboardShell, overview, settings, use-workspace
    forms/                  # Forms list, new form, form detail, use-forms
  lib/
    supabase/
      client.ts             # Browser client (anon key)
      server.ts             # Server client (cookies) + admin client (service role)
      types.ts              # Hand-written Database types (sync with migrations)
supabase/
  migrations/               # Immutable SQL migration files (001-004)
scripts/
  apply-migrations.ts       # Migration applier (tries Postgres + /pg/query + manual fallback)
  verify-migrations.ts      # Verifies schema + RLS + storage after applying migrations
```

## Scalability (50M+ users target)

- UUID primary keys everywhere (no integer overflow)
- BIGINT `submission_seq` per form for stable ordering
- Composite indexes on `(form_id, created_at DESC)` for keyset pagination
- BRIN index on `submissions.created_at` for time-range scans (tiny on disk)
- Submissions NEVER stored in form row — separate `submissions` + `submission_values` tables
- `submission_values` has typed extraction columns (`value_text`, `value_number`, `value_boolean`) populated by trigger, so individual answers can be indexed-queried without jsonb extraction at query time
- Workspace-scoped data model — forms belong to workspaces, not users (multi-tenant ready)
- Cursor/keyset pagination in `useForms` hook (no OFFSET drift)
- All list queries are bounded by `workspace_id` filter (no global scans)

## What's NOT in Phase 1 (reserved for later)

- **AI Form Builder** (Phase 2+) — architecture reserves space for `ai_generations` table
- **Billing / payments** — `workspace_plan` enum exists (free/pro/business/enterprise) but no payment integration
- **Public submission path** — submissions are authed-only for now; Phase 2 adds anonymous submission via `form.public_key`
- **Full drag-and-drop field builder** — current builder supports add/remove/reorder via buttons; full DnD lands in Phase 2
- **Real-time collaboration** — single-editor per form for now
- **Workspace invitations** — `workspace_invites` table exists but no UI yet
- **Form versioning UI** — `form_versions` table is writable but no compare/rollback UI
- **Edge Functions** — none defined yet; `supabaseAdmin()` is ready for when needed

## Testing checklist (Phase 1)

- [x] TypeScript passes (`npx tsc --noEmit`)
- [x] ESLint passes (`bun run lint`)
- [x] Production build passes (`bun run build`)
- [x] Dev server starts without errors
- [x] Landing page renders with zero console errors
- [x] Sign-up flow works (creates auth.users entry, sends verification email)
- [x] Sign-in flow handles wrong password + unverified email correctly
- [x] Protected routes redirect to /signin when unauthenticated
- [x] Authenticated routes redirect to /dashboard when signed in
- [x] Zero horizontal scrolling at all required viewport widths
- [x] Mobile drawer opens/closes correctly
- [x] Form validation shows inline errors
- [x] Toast notifications fire on success/error
- [ ] **Database/RLS tests** — run `bun run scripts/verify-migrations.ts` after applying migrations

## Known limitations

1. **Migrations must be applied manually** via the Supabase Dashboard SQL Editor. The `/pg/query` HTTP endpoint is not enabled on this project, and no database password was provided for direct Postgres connection. The `apply-migrations.ts` script will attempt both methods and fall back to printing manual instructions.
2. **No seeded data** — by design (per spec: "No mock data"). The app shows proper empty states until real data exists.

## License

Proprietary — FormNull.
